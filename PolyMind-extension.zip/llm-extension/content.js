// PolyMind Content Script
// Allows the extension to read page content and selected text

// Listen for messages from popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_PAGE_CONTENT') {
    sendResponse({
      title:    document.title,
      url:      location.href,
      content:  document.body?.innerText?.slice(0, 5000) || '',
      selected: window.getSelection()?.toString() || ''
    });
  }
  return true;
});
