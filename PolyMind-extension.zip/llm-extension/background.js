// PolyMind Background Service Worker

// Context menu for right-click on selected text
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'polymind-ask',
    title: 'Ask PolyMind about "%s"',
    contexts: ['selection']
  });

  chrome.contextMenus.create({
    id: 'polymind-summarize',
    title: 'Summarize this page with PolyMind',
    contexts: ['page']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  chrome.storage.local.set({
    pendingPrompt: info.menuItemId === 'polymind-ask'
      ? `Tell me about: "${info.selectionText}"`
      : 'Please summarize the content of the current page.'
  }, () => {
    chrome.action.openPopup?.();
  });
});
