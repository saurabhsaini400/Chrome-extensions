// ── MODELS CONFIG ──────────────────────────────────────────────────
const MODELS = {
  gemini: {
    label: 'Gemini',
    models: [
      { id: 'gemini-1.5-flash',       name: 'Gemini 1.5 Flash (free)'   },
      { id: 'gemini-1.5-flash-8b',    name: 'Gemini 1.5 Flash-8B (free)'},
      { id: 'gemini-1.5-pro',         name: 'Gemini 1.5 Pro'            },
      { id: 'gemini-2.0-flash-exp',   name: 'Gemini 2.0 Flash Exp'      },
    ]
  },
  groq: {
    label: 'Groq',
    models: [
      { id: 'llama-3.3-70b-versatile', name: 'Llama 3.3 70B' },
      { id: 'llama3-8b-8192',          name: 'Llama 3 8B'    },
      { id: 'mixtral-8x7b-32768',      name: 'Mixtral 8x7B'  },
      { id: 'gemma2-9b-it',            name: 'Gemma 2 9B'    },
    ]
  },
  openrouter: {
    label: 'OpenRouter',
    models: [
      { id: 'meta-llama/llama-3.1-8b-instruct:free',    name: 'Llama 3.1 8B (free)'    },
      { id: 'mistralai/mistral-7b-instruct:free',        name: 'Mistral 7B (free)'       },
      { id: 'google/gemma-2-9b-it:free',                 name: 'Gemma 2 9B (free)'       },
      { id: 'microsoft/phi-3-mini-128k-instruct:free',   name: 'Phi-3 Mini (free)'       },
      { id: 'qwen/qwen-2-7b-instruct:free',              name: 'Qwen 2 7B (free)'        },
    ]
  },
  ollama: {
    label: 'Ollama (Local)',
    models: [
      { id: 'llama3.2',   name: 'Llama 3.2'   },
      { id: 'mistral',    name: 'Mistral'      },
      { id: 'gemma2',     name: 'Gemma 2'      },
      { id: 'qwen2.5',    name: 'Qwen 2.5'     },
      { id: 'phi3',       name: 'Phi-3'        },
      { id: 'codellama',  name: 'Code Llama'   },
    ]
  }
};

// ── STATE ──────────────────────────────────────────────────────────
let state = {
  provider: 'gemini',
  model:    'gemini-1.5-flash',
  messages: [],       // { role, content, images? }
  sessions: [],       // saved sessions
  currentSession: null,
  attachedImages: [], // { dataUrl, base64, mimeType }
  isLoading: false,
  settings: {
    stream: true,
    saveHistory: true,
    autoCode: true,
    systemPrompt: 'You are PolyMind, a helpful AI assistant. Be concise, accurate, and friendly.'
  },
  keys: { gemini: '', groq: '', openrouter: '', ollamaUrl: 'http://localhost:11434' }
};

// ── DOM REFS ───────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const messagesEl    = $('messages');
const emptyState    = $('emptyState');
const userInput     = $('userInput');
const sendBtn       = $('sendBtn');
const modelSelect   = $('modelSelect');
const statusDot     = $('statusDot');
const modelBadge    = $('modelBadge');
const charCount     = $('charCount');
const imagePreview  = $('imagePreviewRow');
const fileInput     = $('fileInput');
const toast         = $('toast');

// ── INIT ───────────────────────────────────────────────────────────
(async () => {
  await loadStorage();
  setupModelChips();
  populateModelSelect();
  updateStatus();
  setupEventListeners();
  loadHistory();
  populateSettings();
})();

async function loadStorage() {
  return new Promise(resolve => {
    chrome.storage.local.get(['keys', 'settings', 'sessions'], data => {
      if (data.keys)     Object.assign(state.keys, data.keys);
      if (data.settings) Object.assign(state.settings, data.settings);
      if (data.sessions) state.sessions = data.sessions;
      resolve();
    });
  });
}

function save() {
  chrome.storage.local.set({
    keys: state.keys,
    settings: state.settings,
    sessions: state.sessions
  });
}

// ── MODEL SETUP ────────────────────────────────────────────────────
function setupModelChips() {
  document.querySelectorAll('.model-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('.model-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      state.provider = chip.dataset.provider;
      populateModelSelect();
      updateStatus();
    });
  });
}

function populateModelSelect() {
  const list = MODELS[state.provider].models;
  modelSelect.innerHTML = list.map(m =>
    `<option value="${m.id}">${m.name}</option>`
  ).join('');
  state.model = list[0].id;
  modelBadge.textContent = state.model;
}

modelSelect.addEventListener('change', () => {
  state.model = modelSelect.value;
  modelBadge.textContent = state.model;
});

async function updateStatus() {
  statusDot.className = 'status-dot checking';
  const ok = await pingProvider();
  statusDot.className = ok ? 'status-dot' : 'status-dot error';
}

async function pingProvider() {
  try {
    if (state.provider === 'gemini') return !!state.keys.gemini;
    if (state.provider === 'groq')   return !!state.keys.groq;
    if (state.provider === 'openrouter') return !!state.keys.openrouter;
    if (state.provider === 'ollama') {
      const r = await fetch(`${state.keys.ollamaUrl}/api/tags`, { signal: AbortSignal.timeout(2000) });
      return r.ok;
    }
  } catch { return false; }
}

// ── QUICK ACTIONS ──────────────────────────────────────────────────
document.querySelectorAll('.quick-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const prompt = btn.dataset.prompt;
    if (prompt.includes('current page') || prompt.includes('selected')) {
      // Get page content
      chrome.tabs.query({ active: true, currentWindow: true }, async tabs => {
        if (!tabs[0]) return;
        try {
          const [result] = await chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            func: () => ({
              url:     location.href,
              title:   document.title,
              content: document.body.innerText.slice(0, 3000)
            })
          });
          userInput.value = `${prompt}\n\nPage: ${result.result.title}\nURL: ${result.result.url}\n\nContent:\n${result.result.content}`;
        } catch {
          userInput.value = prompt;
        }
        autoResize();
      });
    } else {
      userInput.value = prompt;
      userInput.focus();
    }
  });
});

// ── IMAGE ATTACH ───────────────────────────────────────────────────
$('attachBtn').addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', e => {
  [...e.target.files].forEach(f => {
    const reader = new FileReader();
    reader.onload = ev => {
      const dataUrl = ev.target.result;
      const base64  = dataUrl.split(',')[1];
      state.attachedImages.push({ dataUrl, base64, mimeType: f.type });
      renderImagePreviews();
    };
    reader.readAsDataURL(f);
  });
  fileInput.value = '';
});

function renderImagePreviews() {
  if (!state.attachedImages.length) {
    imagePreview.style.display = 'none';
    return;
  }
  imagePreview.style.display = 'flex';
  imagePreview.innerHTML = state.attachedImages.map((img, i) => `
    <div class="img-thumb">
      <img src="${img.dataUrl}" />
      <button class="img-thumb-remove" data-i="${i}">×</button>
    </div>
  `).join('');
  imagePreview.querySelectorAll('.img-thumb-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      state.attachedImages.splice(+btn.dataset.i, 1);
      renderImagePreviews();
    });
  });
}

// ── TEXTAREA ───────────────────────────────────────────────────────
userInput.addEventListener('input', () => {
  autoResize();
  charCount.textContent = userInput.value.length;
  charCount.classList.toggle('warn', userInput.value.length > 2000);
});

userInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});

function autoResize() {
  userInput.style.height = 'auto';
  userInput.style.height = Math.min(userInput.scrollHeight, 120) + 'px';
}

// ── SEND ───────────────────────────────────────────────────────────
sendBtn.addEventListener('click', sendMessage);

async function sendMessage() {
  const text = userInput.value.trim();
  if (!text && !state.attachedImages.length) return;
  if (state.isLoading) return;

  const images = [...state.attachedImages];
  state.attachedImages = [];
  renderImagePreviews();

  const userMsg = { role: 'user', content: text, images };
  state.messages.push(userMsg);
  renderMessage(userMsg);

  userInput.value = '';
  userInput.style.height = 'auto';
  charCount.textContent = '0';
  emptyState.style.display = 'none';

  state.isLoading = true;
  sendBtn.disabled = true;

  const aiEl = appendTypingIndicator();

  try {
    const reply = await callLLM(state.messages);
    aiEl.remove();
    const aiMsg = { role: 'assistant', content: reply };
    state.messages.push(aiMsg);
    renderMessage(aiMsg);
    saveSession(text);
  } catch (err) {
    aiEl.remove();
    const errMsg = { role: 'assistant', content: `⚠️ Error: ${err.message}` };
    state.messages.push(errMsg);
    renderMessage(errMsg);
  } finally {
    state.isLoading = false;
    sendBtn.disabled = false;
    scrollToBottom();
  }
}

// ── LLM ROUTING ───────────────────────────────────────────────────
async function callLLM(messages) {
  switch (state.provider) {
    case 'gemini':     return callGemini(messages);
    case 'groq':       return callGroq(messages);
    case 'openrouter': return callOpenRouter(messages);
    case 'ollama':     return callOllama(messages);
  }
}

// ── GEMINI ─────────────────────────────────────────────────────────
async function callGemini(messages) {
  if (!state.keys.gemini) throw new Error('Gemini API key missing. Go to Settings.');

  const contents = messages.map(m => {
    const parts = [];
    if (m.images?.length) {
      m.images.forEach(img => parts.push({
        inlineData: { mimeType: img.mimeType, data: img.base64 }
      }));
    }
    parts.push({ text: m.content || '' });
    return { role: m.role === 'assistant' ? 'model' : 'user', parts };
  });

  const body = {
    contents,
    systemInstruction: { parts: [{ text: state.settings.systemPrompt }] }
  };

  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${state.model}:generateContent?key=${state.keys.gemini}`,
    { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
  );
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  return data.candidates?.[0]?.content?.parts?.[0]?.text || 'No response.';
}

// ── GROQ ───────────────────────────────────────────────────────────
async function callGroq(messages) {
  if (!state.keys.groq) throw new Error('Groq API key missing. Go to Settings.');

  const msgs = [
    { role: 'system', content: state.settings.systemPrompt },
    ...messages.map(m => ({ role: m.role, content: m.content || '' }))
  ];

  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${state.keys.groq}`
    },
    body: JSON.stringify({ model: state.model, messages: msgs, temperature: 0.7 })
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  return data.choices?.[0]?.message?.content || 'No response.';
}

// ── OPENROUTER ─────────────────────────────────────────────────────
async function callOpenRouter(messages) {
  if (!state.keys.openrouter) throw new Error('OpenRouter API key missing. Go to Settings.');

  const msgs = [
    { role: 'system', content: state.settings.systemPrompt },
    ...messages.map(m => {
      if (m.images?.length) {
        const content = [];
        m.images.forEach(img => content.push({
          type: 'image_url',
          image_url: { url: img.dataUrl }
        }));
        if (m.content) content.push({ type: 'text', text: m.content });
        return { role: m.role, content };
      }
      return { role: m.role, content: m.content || '' };
    })
  ];

  const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${state.keys.openrouter}`,
      'HTTP-Referer': 'chrome-extension://polymind',
      'X-Title': 'PolyMind'
    },
    body: JSON.stringify({ model: state.model, messages: msgs })
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  return data.choices?.[0]?.message?.content || 'No response.';
}

// ── OLLAMA ─────────────────────────────────────────────────────────
async function callOllama(messages) {
  const url = state.keys.ollamaUrl || 'http://localhost:11434';

  const msgs = [
    { role: 'system', content: state.settings.systemPrompt },
    ...messages.map(m => {
      const msg = { role: m.role, content: m.content || '' };
      if (m.images?.length) msg.images = m.images.map(i => i.base64);
      return msg;
    })
  ];

  const res = await fetch(`${url}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: state.model, messages: msgs, stream: false })
  });
  if (!res.ok) throw new Error(`Ollama error ${res.status}. Is Ollama running?`);
  const data = await res.json();
  return data.message?.content || 'No response.';
}

// ── RENDER MESSAGES ────────────────────────────────────────────────
function renderMessage(msg) {
  const div = document.createElement('div');
  div.className = `message ${msg.role === 'user' ? 'user' : 'ai'}`;

  const meta = document.createElement('div');
  meta.className = 'msg-meta';
  meta.innerHTML = msg.role === 'user'
    ? `<div class="msg-avatar user">👤</div><span>You</span>`
    : `<div class="msg-avatar ai">🧠</div><span>${state.model}</span>`;

  const bubble = document.createElement('div');
  bubble.className = 'msg-bubble';

  // Image thumbnails in user message
  if (msg.images?.length) {
    const imgRow = document.createElement('div');
    imgRow.style.cssText = 'display:flex;gap:5px;margin-bottom:7px;flex-wrap:wrap;';
    msg.images.forEach(img => {
      const i = document.createElement('img');
      i.src = img.dataUrl;
      i.style.cssText = 'width:50px;height:50px;object-fit:cover;border-radius:6px;border:1px solid var(--border);';
      imgRow.appendChild(i);
    });
    bubble.appendChild(imgRow);
  }

  // Render content with code block detection
  const content = document.createElement('div');
  content.innerHTML = formatContent(msg.content || '');
  bubble.appendChild(content);

  // Copy buttons for code blocks
  bubble.querySelectorAll('pre').forEach(pre => {
    const btn = document.createElement('button');
    btn.className = 'copy-code-btn';
    btn.textContent = 'copy';
    btn.addEventListener('click', () => {
      navigator.clipboard.writeText(pre.querySelector('code')?.textContent || pre.textContent);
      btn.textContent = 'copied!';
      setTimeout(() => btn.textContent = 'copy', 1500);
    });
    pre.insertBefore(btn, pre.firstChild);
  });

  div.appendChild(meta);
  div.appendChild(bubble);
  messagesEl.appendChild(div);
  scrollToBottom();
}

function formatContent(text) {
  // Escape HTML
  let html = text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  // Code blocks ```lang\n...\n```
  html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) =>
    `<pre><code class="lang-${lang}">${code.trimEnd()}</code></pre>`
  );

  // Inline code
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

  // Bold **text**
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

  // Italic *text*
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');

  // Newlines to <br> (but not inside pre blocks)
  const parts = html.split(/(<pre[\s\S]*?<\/pre>)/);
  html = parts.map((p, i) => i % 2 === 0 ? p.replace(/\n/g, '<br>') : p).join('');

  return html;
}

function appendTypingIndicator() {
  const div = document.createElement('div');
  div.className = 'message ai';
  div.innerHTML = `
    <div class="msg-meta">
      <div class="msg-avatar ai">🧠</div>
      <span>${state.model}</span>
    </div>
    <div class="msg-bubble">
      <div class="typing-indicator">
        <span></span><span></span><span></span>
      </div>
    </div>
  `;
  messagesEl.appendChild(div);
  scrollToBottom();
  return div;
}

function scrollToBottom() {
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

// ── CLEAR CHAT ─────────────────────────────────────────────────────
$('clearChat').addEventListener('click', () => {
  state.messages = [];
  messagesEl.innerHTML = '';
  messagesEl.appendChild(emptyState);
  emptyState.style.display = 'flex';
  showToast('Chat cleared');
});

// ── HISTORY ────────────────────────────────────────────────────────
function saveSession(firstMessage) {
  if (!state.settings.saveHistory) return;
  const id = Date.now().toString();
  const session = {
    id,
    title: firstMessage.slice(0, 50),
    messages: [...state.messages],
    model: state.model,
    provider: state.provider,
    time: new Date().toLocaleString()
  };

  // Update existing or add new
  const idx = state.sessions.findIndex(s => s.id === state.currentSession);
  if (idx >= 0) {
    state.sessions[idx] = { ...state.sessions[idx], messages: [...state.messages] };
  } else {
    state.currentSession = id;
    state.sessions.unshift(session);
    if (state.sessions.length > 50) state.sessions.pop();
  }
  save();
}

function loadHistory() {
  const list = $('historyList');
  if (!state.sessions.length) {
    list.innerHTML = '<div class="history-empty">No chats yet. Start a conversation!</div>';
    return;
  }
  list.innerHTML = state.sessions.map(s => `
    <div class="history-item" data-id="${s.id}">
      <div class="history-title">${escHtml(s.title)}</div>
      <div class="history-meta">${s.model} · ${s.time}</div>
    </div>
  `).join('');

  list.querySelectorAll('.history-item').forEach(item => {
    item.addEventListener('click', () => {
      const session = state.sessions.find(s => s.id === item.dataset.id);
      if (!session) return;
      loadSession(session);
      $('historyPanel').classList.remove('open');
    });
  });
}

function loadSession(session) {
  state.messages = session.messages;
  state.currentSession = session.id;
  state.provider = session.provider;
  state.model = session.model;

  // Update UI
  document.querySelectorAll('.model-chip').forEach(c =>
    c.classList.toggle('active', c.dataset.provider === session.provider)
  );
  populateModelSelect();
  modelSelect.value = session.model;
  modelBadge.textContent = session.model;

  // Re-render messages
  messagesEl.innerHTML = '';
  if (session.messages.length) {
    emptyState.style.display = 'none';
    session.messages.forEach(m => renderMessage(m));
  } else {
    messagesEl.appendChild(emptyState);
  }
}

$('newChatBtn').addEventListener('click', () => {
  state.messages = [];
  state.currentSession = null;
  messagesEl.innerHTML = '';
  messagesEl.appendChild(emptyState);
  emptyState.style.display = 'flex';
  $('historyPanel').classList.remove('open');
});

// ── PANELS ─────────────────────────────────────────────────────────
$('openSettings').addEventListener('click', () => $('settingsPanel').classList.add('open'));
$('closeSettings').addEventListener('click', () => $('settingsPanel').classList.remove('open'));
$('openHistory').addEventListener('click', () => {
  loadHistory();
  $('historyPanel').classList.add('open');
});
$('closeHistory').addEventListener('click', () => $('historyPanel').classList.remove('open'));

// ── SETTINGS POPULATION ────────────────────────────────────────────
function populateSettings() {
  $('geminiKey').value       = state.keys.gemini || '';
  $('groqKey').value         = state.keys.groq || '';
  $('openrouterKey').value   = state.keys.openrouter || '';
  $('ollamaUrl').value       = state.keys.ollamaUrl || 'http://localhost:11434';
  $('systemPrompt').value    = state.settings.systemPrompt || '';

  setToggle('toggleStream',  state.settings.stream);
  setToggle('toggleHistory', state.settings.saveHistory);
  setToggle('toggleCode',    state.settings.autoCode);
}

function setToggle(id, val) {
  $(id).classList.toggle('on', !!val);
}

$('saveKeys').addEventListener('click', () => {
  state.keys.gemini       = $('geminiKey').value.trim();
  state.keys.groq         = $('groqKey').value.trim();
  state.keys.openrouter   = $('openrouterKey').value.trim();
  state.keys.ollamaUrl    = $('ollamaUrl').value.trim() || 'http://localhost:11434';
  state.settings.systemPrompt = $('systemPrompt').value.trim();
  save();
  updateStatus();
  showToast('✓ Saved!');
});

['toggleStream', 'toggleHistory', 'toggleCode'].forEach(id => {
  $(id).addEventListener('click', () => {
    $(id).classList.toggle('on');
    const map = { toggleStream: 'stream', toggleHistory: 'saveHistory', toggleCode: 'autoCode' };
    state.settings[map[id]] = $(id).classList.contains('on');
    save();
  });
});

// ── TOAST ──────────────────────────────────────────────────────────
function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2000);
}

// ── UTILS ──────────────────────────────────────────────────────────
function escHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function setupEventListeners() {
  // Drag & drop image onto textarea
  userInput.addEventListener('dragover', e => e.preventDefault());
  userInput.addEventListener('drop', e => {
    e.preventDefault();
    [...e.dataTransfer.files].filter(f => f.type.startsWith('image/')).forEach(f => {
      const reader = new FileReader();
      reader.onload = ev => {
        const dataUrl = ev.target.result;
        state.attachedImages.push({ dataUrl, base64: dataUrl.split(',')[1], mimeType: f.type });
        renderImagePreviews();
      };
      reader.readAsDataURL(f);
    });
  });

  // Paste image
  document.addEventListener('paste', e => {
    [...(e.clipboardData?.items || [])].forEach(item => {
      if (item.type.startsWith('image/')) {
        const f = item.getAsFile();
        const reader = new FileReader();
        reader.onload = ev => {
          const dataUrl = ev.target.result;
          state.attachedImages.push({ dataUrl, base64: dataUrl.split(',')[1], mimeType: item.type });
          renderImagePreviews();
        };
        reader.readAsDataURL(f);
      }
    });
  });
}
