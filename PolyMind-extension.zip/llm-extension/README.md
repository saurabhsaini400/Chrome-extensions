# 🧠 PolyMind — Free AI Browser Extension

A Claude-like browser extension with **4 free AI providers** and **20+ models**.

---

## 🚀 Quick Install (Chrome)

1. Go to `chrome://extensions/`
2. Enable **Developer mode** (top-right toggle)
3. Click **Load unpacked**
4. Select the `llm-extension` folder

> **Firefox**: Go to `about:debugging` → This Firefox → Load Temporary Add-on → select `manifest.json`

---

## 🔑 Getting Free API Keys

### 🔵 Gemini (Google AI) — FREE
- Visit: https://aistudio.google.com/apikey
- Create a key → paste in Settings
- Free tier: 15 req/min, 1M tokens/day

### 🟣 Groq — FREE (very fast)
- Visit: https://console.groq.com/keys
- Create a key → paste in Settings
- Free tier: 14,400 req/day

### 🟠 OpenRouter — FREE models available
- Visit: https://openrouter.ai/keys
- Create a key → paste in Settings
- Many `:free` models (Llama, Mistral, Gemma, Phi-3, Qwen)

### 🟢 Ollama — 100% Local & Private
- Download: https://ollama.ai
- Run: `ollama pull llama3.2` (or any model)
- No API key needed — runs on your machine!
- Enable CORS for extension: `OLLAMA_ORIGINS=* ollama serve`

---

## ✨ Features

| Feature | Description |
|---|---|
| 🔄 **Multi-provider** | Switch between Gemini, Groq, OpenRouter, Ollama |
| 🖼️ **Image analysis** | Attach, drag-drop, or paste images |
| 📄 **Page summarizer** | One-click summarize any webpage |
| 💻 **Code assistant** | Syntax highlighting + copy button |
| 📚 **Chat history** | Sessions saved locally |
| 🖱️ **Right-click menu** | Select text → Ask PolyMind |
| ⚙️ **System prompt** | Customize AI behavior |
| 🔐 **Privacy-first** | Keys stored locally, never sent anywhere |

---

## 🛠️ Models Available

| Provider | Models |
|---|---|
| Gemini | 1.5 Flash (free), 1.5 Flash-8B (free), 1.5 Pro, 2.0 Flash Exp |
| Groq | Llama 3.3 70B, Llama 3 8B, Mixtral 8x7B, Gemma 2 9B |
| OpenRouter | Llama 3.1 8B, Mistral 7B, Gemma 2 9B, Phi-3 Mini, Qwen 2 7B |
| Ollama | Llama 3.2, Mistral, Gemma 2, Qwen 2.5, Phi-3, Code Llama, + any local model |

---

## 📁 Project Structure

```
llm-extension/
├── manifest.json     # Extension config (MV3)
├── popup.html        # Main UI
├── popup.js          # Chat logic + API calls
├── background.js     # Context menu service worker
├── content.js        # Page content extraction
├── icons/            # Extension icons
└── README.md
```

---

## 💡 Tips

- **Shift+Enter** for newlines in chat
- **Paste** an image directly into the chat box
- **Drag & drop** images onto the text area
- Use the **quick action buttons** to summarize or explain page content
- Ollama users: add custom models by editing the `MODELS.ollama.models` array in `popup.js`
